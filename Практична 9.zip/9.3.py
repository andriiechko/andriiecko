class Book():
    title = "1"
    author = '2'
    availability = '3'

    def display_info(self):
        print(self.title, self.author, self.availability)

class EBook(Book):
    def __init__(self):
        self.format = 'pdf'
    def display_info(self):
        print(self.title, self.author, self.availability, self.format)


class Library():
    def __init__(self):
        self.books = []


    def add(self, book):
        self.books.append(book)

    def display(self):
        for book in self.books:
            print(book.title)

    def delete(self, book):
        self.books.remove(book)

    def lean(self, book):
        print(f'Книга {book} позичена')

    def ref(self, book):
        print(f'Книга {book} повернена')


b = EBook()
b.display_info()

lb = Library()
lb.add(b)
lb.delete(b)
lb.display()




