from abc import ABC, abstractmethod
import math

class Shape(ABC):
    @abstractmethod
    def area(self):
        pass

    @abstractmethod
    def describe(self):
        print(self)

class Circle(Shape):
    def __init__(self):
        self.radius = 12

    def describe(self):
        print(f"Коло:\nРадіус: {self.radius}")

    def area(self):
        print(f"Площа кола: {math.pi * self.radius ** 2}\n\n")


class Rectangle(Shape):
    def __init__(self):
        self.width = 8
        self.height = 9

    def describe(self):
        print(f"КВАДРАТ:\nШирина квадрата - {self.width}\nВисота - {self.height}")

    def area(self):
        print(f"Площа квадрату: {self.height * self.width}")


circle = Circle()
circle.describe()
circle.area()

rectangle = Rectangle()
rectangle.describe()
rectangle.area()






