class Student_petro():
    name = 'petro'
    age = '16'
    grade = '2'
    def display_info(self):
        return self.name, self.grade, self.age

class Student_vitalya():
    name = 'vitalya'
    age = '16'
    grade = '6'
    def display_info(self):
        return self.name, self.grade, self.age


class Student_igor():
    name = 'igor'
    age = '15'
    grade = '8'
    def display_info(self):
        return self.name, self.grade, self.age


student_petro = Student_petro()
print(student_petro.display_info())

student_vitalya = Student_vitalya()
print(student_vitalya.display_info())

student_igor = Student_igor()
print(student_igor.display_info())